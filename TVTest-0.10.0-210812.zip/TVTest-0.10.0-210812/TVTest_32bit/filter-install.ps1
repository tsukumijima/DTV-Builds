﻿
# 管理者権限で実行されていない場合、自動的に管理者に昇格する
if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole('Administrators')) {
    Start-Process powershell.exe "-File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# カレントディレクトリのパス
$CurrentPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)

# コンソールウインドウのサイズを変更する
(Get-Host).UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(108,25)
(Get-Host).UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(108,25)

Write-Host ''
Write-Host ''

function Pause {
    Write-Host ''
    Write-Host '    終了するには何かキーを押してください。'
    (Get-Host).UI.RawUI.ReadKey('NoEcho,IncludeKeyDown') | Out-Null
}

# TVTestVideoDecoder をインストール
regsvr32.exe (Join-Path $CurrentPath TVTestVideoDecoder.ax) /s
if ($? -eq $False) {
    Write-Host '    DirectShow フィルタのインストールに失敗しました。'
    Pause
    exit
}

# TvtAudioStretchFilter をインストール
regsvr32.exe (Join-Path $CurrentPath TvtAudioStretchFilter.ax) /s
if ($? -eq $False) {
    Write-Host '    DirectShow フィルタのインストールに失敗しました。'
    Pause
    exit
}

# フォントのインストール
# ref: https://gist.github.com/anthonyeden/0088b07de8951403a643a8485af2709b#gistcomment-3651336
$SystemFontsPath = Join-Path $env:WINDIR 'Fonts'
$FontsPath = Join-Path $CurrentPath '\Plugins\TVCaptionMod2'
foreach ($Font in Get-ChildItem $FontsPath -Include '*.ttc' -recurse) {

    # すでにフォントがインストールされている
	if (Test-Path -Path (Join-Path $SystemFontsPath $Font.Name)) {
		continue
    }

    # レジストリのフォント情報を抽出する
    $ShellFolder = (New-Object -COMObject Shell.Application).Namespace($FontsPath)
    $ShellFile = $ShellFolder.ParseName($Font.name)
    $ShellFileType = $ShellFolder.GetDetailsOf($ShellFile, 2)
    if ($ShellFileType -Like '*TrueType font file*') {
        $FontType = '(TrueType)'
    }

    # レジストリを更新し、フォントをコピーする
    $RegName = $ShellFolder.GetDetailsOf($ShellFile, 21) + ' ' + $FontType
    New-ItemProperty -Name $RegName -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts' -PropertyType string -Value $Font.name -Force | Out-Null
    Copy-item $Font.FullName -Destination $SystemFontsPath
}

Write-Host '    DirectShow フィルタのインストールに成功しました。'
Write-Host '    配置フォルダを変更する場合は、もう一度 filter-install.ps1 を右クリックメニューから実行してください。'
Pause
