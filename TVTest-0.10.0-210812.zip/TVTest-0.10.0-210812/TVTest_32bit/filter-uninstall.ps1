﻿
# 管理者権限で実行されていない場合、自動的に管理者に昇格する
if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole('Administrators')) {
    Start-Process powershell.exe "-File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# カレントディレクトリのパス
$CurrentPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)

# コンソールウインドウのサイズを変更する
(Get-Host).UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(108,25)
(Get-Host).UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(108,25)

Write-Host ''
Write-Host ''

function Pause {
    Write-Host ''
    Write-Host '    終了するには何かキーを押してください。'
    (Get-Host).UI.RawUI.ReadKey('NoEcho,IncludeKeyDown') | Out-Null
}

# TVTestVideoDecoder をアンインストール
regsvr32.exe (Join-Path $CurrentPath TVTestVideoDecoder.ax) /u /s
if ($? -eq $False) {
    Write-Host '    DirectShow フィルタのアンインストールに失敗しました。'
    Pause
    exit
}

# TvtAudioStretchFilter をアンインストール
regsvr32.exe (Join-Path $CurrentPath TvtAudioStretchFilter.ax) /u /s
if ($? -eq $False) {
    Write-Host '    DirectShow フィルタのアンインストールに失敗しました。'
    Pause
    exit
}

Write-Host '    DirectShow フィルタのアンインストールに成功しました。'
Write-Host '    TVTest 本体をアンインストールする場合は、このフォルダごと削除してください。'
Pause
