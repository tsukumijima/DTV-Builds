﻿
=====================================================================
                       EDCB (tkntrec版) 2020/02/09                    
=====================================================================

◆ ビルドにあたって

・VS2019 でビルドしています。別途ランタイムが必要かもしれません。
・32bit 版・64bit 版両方を同梱しています。EDCB_32bit 以下が 32bit 版、EDCB_64bit 以下が 64bit 版です。
・EpgDataCap_Bon・EpgTimerSrv などのフォントを ＭＳ Ｐゴシック から Meiryo UI に変更したこと以外の変更は行っていません（ C++ の知識がない…）。
・変更したコードは https://github.com/tsukumijima/EDCB にて公開しています。
・HttpPublic.ini を同梱しています（後述）。
  ・そのため、HttpPublic.ini の設定をカスタマイズしている場合、単純に上書きしてしまうと設定ファイルも同梱されているもので上書きされてしまいます。
  ・設定を上書きしたくない場合は、ファイルをリネームして上書きされないようにしてから上書きしてください。
・万全は尽くしていますが、もしかするとファイルの不備や動かない、といったことがあるかもしれません。自己責任にてお願いします。

◆ 同梱ファイル (EDCB 本体に付属のファイル以外)

EDCB を利用する上で必須、またはあった方が良さそうなファイルを一緒に同梱しています。

・B25Decoder.dll … B-CAS カードを使い CAS 処理 (スクランブル解除) を行うライブラリ
  ・B25Decoder がないと CAS 処理を行えないため、必須のライブラリです（要するに録画できても見れない）
  ・https://github.com/epgdatacapbon/libaribb25 をビルドしたものを同梱しています (libaribb25 は B25Decoder(本家)互換です・libaribb25.dll を B25Decoder.dll にリネームしています)
・EMWUI_Readme.md … EDCB_Material_WebUI（後述）の説明書 (markdown 形式)
・lua52.dll・zlib.dll … EDCB_Material_WebUI を実行するために必要なライブラリ
  ・このライブラリがないと EDCB_Material_WebUI を実行できません
  ・EDCB-Work-Plus-s (https://github.com/xtne6f/EDCB/releases/) に入っていたものを同梱しています
・EdcbPlugIn/ch2chset.vbs・EdcbPlugIn/EdcbPlugIn.ini・EdcbPlugIn_Readme.txt … EDCB-Work-Plus-s (https://github.com/xtne6f/EDCB/releases/) に入っていたものを同梱しています
・EdcbPlugIn/Write_Multi.dll・EdcbPlugIn/Write_OneService.dll … EdcbPlugIn を使う場合に必要なファイル書き出し用プラグイン
  ・EdcbPlugIn を使う場合は TVTest.exe と同じフォルダに置く必要があります
  ・Write_Multi.dll は https://github.com/xtne6f/Write_Multi をビルドしたものです
  ・Write_OneService.dll は Tools フォルダに入っているものをコピーしたものです
・HttpPublic/api/・HttpPublic/EMWUI/・HttpPublic/img/・HttpPublic/video/ … EDCB_Material_WebUI 本体
  ・PWA 対応などの改良を行った EDCB_Material_WebUI (https://github.com/tsukumijima/EDCB_Material_WebUI) を同梱しています 
  ・HttpPublic/img/logo/ には私が関東圏にて取得した 地デジ・BS・CS110 の局ロゴ (bmp) を同梱しています
  ・局ロゴが表示されない放送局がある場合は、TVTest で取得した局ロゴを HttpPublic/img/logo/ に入れてみてください
  ・EDCB_Material_WebUI を使う場合は別途いくつか設定が必要です、https://github.com/tsukumijima/EDCB_Material_WebUI/blob/master/README.md を参考に設定を行ってください
・Setting/HttpPublic.ini … EDCB_Material_WebUI の設定ファイル
  ・すぐに使えるよう、予めいくつかの設定を行っています
  ・先述の通り、カスタマイズしている場合は上書きしないよう注意してください
・Tools/ffmpeg.exe・Tools/ffprobe.exe … EDCB_Material_WebUI がファイル再生やファイル情報の取得に利用する動画変換ソフト / 動画情報取得ソフト
  ・ffmpeg-4.2.2-shared (https://ffmpeg.zeranoe.com/builds/) を同梱しています
  ・ffmpeg-4.2.2-shared のうち ffplay.exe は不要なため削除しています
  ・Shared 版にしている理由は ffmpeg と ffprobe でライブラリを共通化でき、ファイルサイズを半分近くにまで減らせるからです

=====================================================================
